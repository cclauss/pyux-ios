PyUx script examples
